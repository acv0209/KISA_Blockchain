package com.sotolab.code;

import java.io.IOException;
import java.security.PublicKey;

import io.blocko.coinstack.AbstractEndpoint;
import io.blocko.coinstack.CoinStackClient;
import io.blocko.coinstack.exception.CoinStackException;
import io.blocko.coinstack.model.BlockchainStatus;
import io.blocko.coinstack.model.CredentialsProvider;

public class AClient {

	public static void main(String[] args) throws IOException, CoinStackException {

		// 1. Coinstack SDK Client 생성
		CredentialsProvider credentials = null;
		AbstractEndpoint endpoint = new AbstractEndpoint() {
			public String endpoint() {
				return "http://testchain.blocko.io";
			}

			public boolean mainnet() {
				return true;
			}

			public PublicKey getPublicKey() {
				return null;
			}
		};
		CoinStackClient client = new CoinStackClient(credentials, endpoint);

		// 2. block chain status 조회
		BlockchainStatus status = client.getBlockchainStatus();
		System.out.println("bestHeight: " + status.getBestHeight());
		System.out.println("bestBlockHash: " + status.getBestBlockHash());

	}
}
