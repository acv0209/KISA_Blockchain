package com.sotolab.code;

import java.io.IOException;
import java.security.PublicKey;

import io.blocko.coinstack.AbstractEndpoint;
import io.blocko.coinstack.CoinStackClient;
import io.blocko.coinstack.ECKey;
import io.blocko.coinstack.TransactionBuilder;
import io.blocko.coinstack.exception.CoinStackException;
import io.blocko.coinstack.model.Block;
import io.blocko.coinstack.model.BlockchainStatus;
import io.blocko.coinstack.model.CredentialsProvider;
import io.blocko.coinstack.model.Output;

public class HTransaction {
	
	public static void main(String[] args) throws IOException, CoinStackException { 
		
		 // 1. Coinstack SDK Client 생성
		CredentialsProvider credentials = null;
		AbstractEndpoint endpoint = new AbstractEndpoint() {
			public String endpoint() {
				return "http://testchain.blocko.io";
			}
			
			public boolean mainnet() {
				return true;
			}
			public PublicKey getPublicKey() {
				return null;
			}
		};
		CoinStackClient client = new CoinStackClient(credentials, endpoint);
		
		// 2. block chain status 조회
		System.out.println("2");
		BlockchainStatus status = client.getBlockchainStatus();
		System.out.println("bestHeight: "+ status.getBestHeight());
		System.out.println("bestBlockHash: "+ status.getBestBlockHash());
		
		// 3. Block 조회
		Block block = client.getBlock("YOUR_BLOCK_ADDR");
		System.out.println("3");
		System.out.println("blockId: " + block.getBlockId());
		System.out.println("parentId: " + block.getParentId());
		System.out.println("height: " + block.getHeight());
		System.out.println("time: " + block.getBlockConfirmationTime());
		
		// 4. Private Key 생성
		// create a new private key
		
		String newPrivateKeyWIF = "YOUR_PRIVATE_KEY";
		System.out.println("private key: " + newPrivateKeyWIF);
		
		// 5. Public Key 생성
		// derive a public key
		//String newPublicKey = Hex.encodeHexString(ECKey.derivePubKey(newPrivateKeyWIF, false));
		String newPublicKey = "YOUR_PUBLIC_KEY";
		System.out.println("public key: " + newPublicKey);
		
		// 6. Wallet address
		//String your_wallet_address = ECKey.deriveAddress(newPrivateKeyWIF);
		String your_wallet_address = "YOUR_WALLET_ADDR";
		System.out.println("address: " + your_wallet_address);
		
		// 7. Address balance
		// get a remaining balance
		long balance = client.getBalance(your_wallet_address);
		System.out.println("balance: " + balance);
		
		// 8. Wallet Transaction History
		// print all transactions of a given wallet address
		String[] transactionIds = client.getTransactions(your_wallet_address);
		System.out.println("transactions");
		for (String txId : transactionIds) {
		  System.out.println("txIds[]: " + txId);
		}
		
		// 9. Wallet UXTO
		//print all utxos
		Output[] outputs = client.getUnspentOutputs(your_wallet_address);
		System.out.println("unspent outputs"); 
		for (Output utxo: outputs) { 
		    System.out.println(utxo.getValue());
		}
		
		// 10. Transaction
		String toPrivateKeyWIF = ECKey.createNewPrivateKey();
		String toAddress = ECKey.deriveAddress(toPrivateKeyWIF);
			
		// 10-1 create a transaction
		long amount = io.blocko.coinstack.Math.convertToSatoshi("0.0002");
		long fee = io.blocko.coinstack.Math.convertToSatoshi("0.0001");
		
		TransactionBuilder builder = new TransactionBuilder();
		builder.addOutput(toAddress, amount);
		builder.setFee(fee);
		
		// 10-2 sign the transaction using the private key
		String rawSignedTx = client.createSignedTransaction(builder, newPrivateKeyWIF);
		System.out.println(rawSignedTx);
	}
	
}
