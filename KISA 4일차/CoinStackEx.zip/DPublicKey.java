package com.sotolab.code;

import java.io.IOException;
import java.security.PublicKey;

import io.blocko.apache.commons.codec.binary.Hex;
import io.blocko.coinstack.AbstractEndpoint;
import io.blocko.coinstack.CoinStackClient;
import io.blocko.coinstack.ECKey;
import io.blocko.coinstack.exception.CoinStackException;
import io.blocko.coinstack.model.Block;
import io.blocko.coinstack.model.BlockchainStatus;
import io.blocko.coinstack.model.CredentialsProvider;

public class DPublicKey {
	
	public static void main(String[] args) throws IOException, CoinStackException { 
		
		 // 1. Coinstack SDK Client 생성
		CredentialsProvider credentials = null;
		AbstractEndpoint endpoint = new AbstractEndpoint() {
			public String endpoint() {
				return "http://testchain.blocko.io";
			}
			
			public boolean mainnet() {
				return true;
			}
			public PublicKey getPublicKey() {
				return null;
			}
		};
		CoinStackClient client = new CoinStackClient(credentials, endpoint);
		
		// 2. block chain status 조회
		System.out.println("2");
		BlockchainStatus status = client.getBlockchainStatus();
		System.out.println("bestHeight: "+ status.getBestHeight());
		System.out.println("bestBlockHash: "+ status.getBestBlockHash());
		
		// 3. Block 조회
		Block block = client.getBlock("YOUR_BLOCK_ADDR");
		System.out.println("3");
		System.out.println("blockId: " + block.getBlockId());
		System.out.println("parentId: " + block.getParentId());
		System.out.println("height: " + block.getHeight());
		System.out.println("time: " + block.getBlockConfirmationTime());
		
		// 4. Private Key 생성
		// create a new private key
		//String newPrivateKeyWIF = ECKey.createNewPrivateKey();
		String newPrivateKeyWIF = "YOUR_PRIVATE_KEY";
		System.out.println("private key: " + newPrivateKeyWIF);
		
		// 5. Public Key 생성
		// derive a public key
		String newPublicKey = Hex.encodeHexString(ECKey.derivePubKey(newPrivateKeyWIF, false));
		System.out.println("public key: " + newPublicKey);

		String newPublicKey2 = Hex.encodeHexString(ECKey.derivePubKey(newPrivateKeyWIF, false));
		System.out.println("public key2: " + newPublicKey);
	}
	
}
